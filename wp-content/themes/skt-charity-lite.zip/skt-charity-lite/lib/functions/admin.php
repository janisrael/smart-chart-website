<?php
 /**
 * The ADMIN functions for SKT Charity Lite
 *
 * Stores all the admin functions of the template.
 *
 * @package SKT Charity Lite
 * 
 * @since SKT Charity Lite 1.0
 */
 


/**************** LOAD RAW CSS & JS ON BACKEND ****************/
add_action('admin_head', 'complete_editor_fix');

function complete_editor_fix() {}